export class Cake{
    name!: string
    price!: number
    image!: string
    cakeid!:string
    special!:boolean
}      

export class UserInfo{
    username!: String
    email!: String
    password!:String
}